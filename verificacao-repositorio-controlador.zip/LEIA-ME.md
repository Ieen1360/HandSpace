# Verificação do repositório (sem executar testes)

Na raiz do repositório (a pasta que contém `HandSpace/`):

    bash verificar-controlador.sh .

Interpretação:
- "OK (v0.4.1 (novo))" em todos os arquivos: o repositório tem a versão corrigida. Se os testes ainda
  falham, o problema está em outro ponto e é preciso enviar o XML de resultado do Gradle.
- "ANTIGO": o repositório ainda tem a versão anterior. Esse é o estado que reproduz exatamente as três
  falhas relatadas. É preciso confirmar que o commit enviado contém os arquivos novos.
- "marcadores": `buttonCooldowns` deve aparecer e `slot.cooldown` não deve.

Não modifica nenhum arquivo. Não substitui `gradle testDebugUnitTest`.
