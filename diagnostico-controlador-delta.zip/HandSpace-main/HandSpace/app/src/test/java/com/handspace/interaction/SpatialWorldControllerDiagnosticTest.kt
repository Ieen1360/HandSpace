package com.handspace.interaction

import com.handspace.gesture.HandGesture
import com.handspace.spatial.Camera3D
import com.handspace.spatial.DemoWorld
import com.handspace.spatial.MenuAction
import com.handspace.testutil.Pose
import com.handspace.testutil.SyntheticHands
import com.handspace.tracking.Handedness
import com.handspace.tracking.TrackedHand
import com.handspace.tracking.ViewTransform
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Diagnóstico: mesmos cenários dos três testes que falham, com uma asserção por etapa e mensagens
 * explícitas. Não substitui nem altera SpatialWorldControllerTest. Serve para localizar a primeira
 * etapa que diverge do esperado na execução real do Gradle.
 */
class SpatialWorldControllerDiagnosticTest {

    private val transform = ViewTransform.fillCenter(1000, 1000, 1000f, 1000f)
    private val camera = Camera3D(1000f, 1000f)

    private fun pinch(side: Handedness, sx: Float, sy: Float): TrackedHand =
        SyntheticHands.trackedHand(side, Pose.PINCH, sx / 1000f - 0.35f, sy / 1000f - 0.2f)

    private fun open(side: Handedness, sx: Float, sy: Float): TrackedHand =
        SyntheticHands.trackedHand(side, Pose.OPEN, sx / 1000f - 0.35f, sy / 1000f - 0.2f)

    private fun screenOf(center: com.handspace.spatial.Vec3): Pair<Float, Float> {
        val p = camera.project(center)!!
        return p.x to p.y
    }

    @Test
    fun diag_objectsButton() {
        val world = DemoWorld.create()
        val c = SpatialWorldController(world, onCameraAction = {}, stableFrames = 1)
        c.interactive = true
        val sphere = world.get(DemoWorld.SPHERE_ID)!!
        val (sx, sy) = screenOf(sphere.center)
        val (ox, oy) = screenOf(world.get("menu_${MenuAction.OBJECTS.name.lowercase()}")!!.center)

        c.onFrame(SyntheticHands.frame(0, pinch(Handedness.RIGHT, sx, sy)), transform, camera, 0)
        assertEquals("t=0 gesto", HandGesture.PINCH, c.hands.single().gesture)
        assertEquals("t=0 segurando", "world_sphere", c.hands.single().holdingId)

        c.onFrame(SyntheticHands.frame(33, open(Handedness.RIGHT, sx, sy)), transform, camera, 33)
        assertEquals("t=33 gesto", HandGesture.OPEN_HAND, c.hands.single().gesture)
        assertEquals("t=33 segurando (esperado nenhum após soltar)", null, c.hands.single().holdingId)

        c.onFrame(SyntheticHands.frame(300, pinch(Handedness.RIGHT, ox, oy)), transform, camera, 300)
        assertEquals("t=300 gesto", HandGesture.PINCH, c.hands.single().gesture)
        assertEquals("t=300 alvo sob o dedo", "menu_objects", c.hands.single().hoverId)
        assertEquals("t=300 esfera visível após acionar Objetos", false, sphere.visible)
    }

    @Test
    fun diag_grabbingSphere_thenCamera() {
        val world = DemoWorld.create()
        var cameraActions = 0
        val c = SpatialWorldController(world, onCameraAction = { cameraActions++ }, stableFrames = 1)
        c.interactive = true
        val sphere = world.get(DemoWorld.SPHERE_ID)!!
        val (sx, sy) = screenOf(sphere.center)
        val (cx, cy) = screenOf(world.get("menu_camera")!!.center)

        c.onFrame(SyntheticHands.frame(0, pinch(Handedness.RIGHT, sx, sy)), transform, camera, 0)
        assertEquals("t=0 segurando a esfera", "world_sphere", c.hands.single().holdingId)

        c.onFrame(SyntheticHands.frame(33, open(Handedness.RIGHT, sx, sy)), transform, camera, 33)
        assertEquals("t=33 gesto", HandGesture.OPEN_HAND, c.hands.single().gesture)

        c.onFrame(SyntheticHands.frame(100, pinch(Handedness.RIGHT, cx, cy)), transform, camera, 100)
        assertEquals("t=100 gesto", HandGesture.PINCH, c.hands.single().gesture)
        assertEquals("t=100 alvo sob o dedo", "menu_camera", c.hands.single().hoverId)
        assertEquals("t=100 ações da câmera", 1, cameraActions)
    }
}
